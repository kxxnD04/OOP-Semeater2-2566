public abstract class Item {
    public abstract void use(Player P);
}
